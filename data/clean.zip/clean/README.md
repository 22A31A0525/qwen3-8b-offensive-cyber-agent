# Qwen3-8B Latest Version (v3) -- Derived Clean Dataset Specification (`data/clean/`)

[![Status](https://img.shields.io/badge/Dataset-Production%20Ready-green.svg)](#1-executive-summary--verification-clearance)
[![Curriculum](https://img.shields.io/badge/Curriculum-60%2F20%2F20%20Enforced-orange.svg)](#4-mathematical-reconciliation-matrix)
[![Decontamination](https://img.shields.io/badge/Audit-4--Tier%20PASS%20(0%20Leaks)-blue.svg)](#6-clinical-decontamination-review-summary)
[![Integrity](https://img.shields.io/badge/Integrity-SHA--256%20Locked-purple.svg)](#2-cryptographic-checksum-manifest)

## 1. Executive Summary & Verification Clearance

This directory contains the **versioned derived clean release** of the training, validation, and benchmarking assets for **Qwen3-8B Latest Version (v3)**. It resolves all cross-split contamination findings identified during the 4-Tier Decontamination Audit while strictly adhering to **Rule 1 (Dataset Immutability)** by leaving the original frozen master dataset (`v3_pipeline/data/`) untouched.

| Metric Dimension                 | Target Standard            | Observed Value                                       | Verification Status                                                        |
| :------------------------------- | :------------------------- | :--------------------------------------------------- | :------------------------------------------------------------------------- |
| **Train vs. Test Contamination** | 0 confirmed leaks          | **0 Confirmed Leaks**                                | **PASS: No confirmed cross-split leakage under completed audit**           |
| **Train vs. Val Contamination**  | 0 confirmed leaks          | **0 Confirmed Leaks**                                | **PASS: No confirmed cross-split leakage under completed audit**           |
| **Val vs. Test Contamination**   | 0 confirmed leaks          | **0 Confirmed Leaks**                                | **PASS: No confirmed cross-split leakage under completed audit**           |
| **Test Set Cryptographic Hash**  | Byte-for-byte frozen match | `fabd494f98bd5e79e81c3b6e3c740db99a1b0d5abcfd0d2...` | **PASS (100% Bit-for-Bit)**                                                |
| **Curriculum Distribution**      | 60% / 20% / 20%            | 3,120 Exploit / 1,040 Reasoning / 1,040 Replay       | **PASS (Exact Ratios)**                                                    |
| **Decontamination Gate**         | Pass before Phase 0        | All 36 automated critical flags reconciled benign    | **PASS: No confirmed cross-split leakage remaining under completed audit** |
---

## 2. Cryptographic Checksum Manifest

Every file in this derived release has its cryptographic SHA-256 hash verified:

| File Name         | Split Scope                | Dialogues | SHA-256 Cryptographic Checksum                                     | Provenance Status          |
| :---------------- | :------------------------- | --------: | :----------------------------------------------------------------- | :------------------------- |
| **`train.jsonl`** | Unified Training Set       |     5,200 | `210d9989969caa3102a1ee3c61e279b5837b4e2c807fdc73a54bc334e96ad465` | Versioned Clean Release    |
| **`val.jsonl`**   | Unified Validation Set     |       650 | `95e7def8fc6b03362d4fdff507c781ff7613ab0dbf03b20ed257974e7d41bdfd` | Versioned Clean Release    |
| **`test.jsonl`**  | Unified Benchmark Test Set |       650 | `fabd494f98bd5e79e81c3b6e3c740db99a1b0d5abcfd0d2e40a72606721f02d5` | Identical to Frozen Master |
---

## 3. Segregated Split Manifest

Directory architecture follows **Approach A (Split-First Segregation)**:

| Directory    | File Name                 | Domain / Track          | Records | Split % | Total % | Description                                     |
| :----------- | :------------------------ | :---------------------- | ------: | ------: | ------: | :---------------------------------------------- |
| **`train/`** | `exploit_60pct.jsonl`     | Exploit & Red-Teaming   |   3,120 |   60.0% |   48.0% | Multi-turn security testing & exploitation      |
| **`train/`** | `reasoning_20pct.jsonl`   | Cybersecurity Reasoning |   1,040 |   20.0% |   16.0% | Deep CoT security reasoning questions           |
| **`train/`** | `tool_replay_20pct.jsonl` | Tool-Calling Replay     |   1,040 |   20.0% |   16.0% | Multi-turn tool invocation & schema execution   |
| **`val/`**   | `exploit_60pct.jsonl`     | Exploit & Red-Teaming   |     390 |   60.0% |    6.0% | Validation exploit dialogues                    |
| **`val/`**   | `reasoning_20pct.jsonl`   | Cybersecurity Reasoning |     130 |   20.0% |    2.0% | Validation reasoning questions                  |
| **`val/`**   | `tool_replay_20pct.jsonl` | Tool-Calling Replay     |     130 |   20.0% |    2.0% | Validation tool-call replay dialogues           |
| **`test/`**  | `exploit_60pct.jsonl`     | Exploit & Red-Teaming   |     390 |   60.0% |    6.0% | Independent exploit benchmark (Track 2)         |
| **`test/`**  | `reasoning_20pct.jsonl`   | Cybersecurity Reasoning |     130 |   20.0% |    2.0% | Independent reasoning benchmark (Track 1)       |
| **`test/`**  | `tool_replay_20pct.jsonl` | Tool-Calling Replay     |     130 |   20.0% |    2.0% | Independent tool benchmark (Track 3, 479 turns) |
---

## 4. Mathematical Reconciliation Matrix

Exact record distribution across all three splits:

| Track / Domain                          | Training (80%) | Validation (10%) | Testing (10%) | Total Records | Overall Curriculum % |
| :-------------------------------------- | -------------: | ---------------: | ------------: | ------------: | -------------------: |
| **Exploit / Multi-Turn Security**       |      **3,120** |          **390** |       **390** |     **3,900** |           **60.00%** |
| **Cybersecurity Knowledge & Reasoning** |      **1,040** |          **130** |       **130** |     **1,300** |           **20.00%** |
| **Tool-Calling Replay**                 |      **1,040** |          **130** |       **130** |     **1,300** |           **20.00%** |
| **Total Dialogues**                     |      **5,200** |          **650** |       **650** |     **6,500** |          **100.00%** |
---

## 5. Remediation Lineage & Swap Provenance

During the 4-tier audit, two dialogue entities were confirmed as cross-split near-duplicates between splits. To eliminate leakage without altering curriculum distribution or total count, they were replaced with unused dialogues from the deduplicated Hermes pool:

| Split | Quarantined Leaked Record ID                  | Replacement Record ID                         | Task Description                                |
| :---- | :-------------------------------------------- | :-------------------------------------------- | :---------------------------------------------- |
| Train | `hermes_7e118bec-7d0b-462a-950e-a652743bf76e` | `hermes_3df7b85e-9f33-40a7-bc45-12cf2c5950d4` | Replaced NY Italian restaurant search duplicate |
| Val   | `hermes_bfc12eb2-fea8-4c51-b695-33c16030d4c9` | `hermes_a8637e3d-ff96-418c-8519-5d23b320ce13` | Replaced Sci-Fi movie search duplicate          |
---

## 6. Clinical Decontamination Review Summary

The remaining automated flags detected on this derived release were manually evaluated:

| Category                          | Pairs | Clinical Disposition | Rationale                                                                                  |
| :-------------------------------- | ----: | :------------------- | :----------------------------------------------------------------------------------------- |
| **Generic Mock Tool Outputs**     |    21 | **BENIGN**           | Identical scalar outputs (`{"returns": true}`) in distinct, independent tasks.             |
| **Diagnostic Prompt Scaffolding** |    15 | **BENIGN**           | Shared boilerplate wrapper (`Diagnose the following failure:`) with distinct error traces. |
| **Harmless Command Overlap**      |     6 | **BENIGN**           | Shared administrative concepts (e.g. bash-to-PowerShell) without secret leakage.           |
| **Confirmed Leaks Remaining**     | **0** | **CLEAN**            | **Zero test set questions, answers, or flags leak into the training split.**               |
---

## 7. Mandatory Training & Ingestion Directives

Any training pipeline ingesting this directory must adhere to:

1. **Canonical Tool Schema Rendering**: Render `<tools>` XML schema into the system prompt for 100% of tool-calling records.
2. **Globally Deterministic DDP Sampler**: Enforce 3:1:1 curriculum ratio sharded across DDP ranks with disjoint sample assignment.
3. **Multi-Turn Assistant-Only Loss Masking**: Assign `labels = -100` on system, tools, user, and tool return turns. Supervise only assistant tokens.
